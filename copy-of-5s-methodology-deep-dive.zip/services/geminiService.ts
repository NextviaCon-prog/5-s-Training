import { GoogleGenAI, Type, Modality } from "@google/genai";
import type { ResearchData, ResearchSection, SubTopic } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const subTopicSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "The title of the sub-topic (e.g., 'Sort / Seiri')." },
        description: { type: Type.STRING, description: "A brief, one-sentence description of the sub-topic." },
    },
    required: ['title', 'description'],
};

const sectionSchema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "The title of the research section." },
    content: {
      type: Type.ARRAY,
      description: "An array of 3-5 concise, key points or paragraphs about the topic. This should be empty if subTopics are provided.",
      items: { type: Type.STRING },
    },
    subTopics: {
        type: Type.ARRAY,
        description: "An array of sub-topics, only for parent topics like 'How It Works'. Should be empty for leaf-node topics.",
        items: subTopicSchema,
    }
  },
  required: ['title', 'content'],
};

const prompts: Record<keyof ResearchData, string> = {
    origins: "Generate a parent report section for the 'Origins of 5S'. Your primary goal is to define 3-4 key historical stages or influences as sub-topics. Examples could include 'Post-WWII Japanese Industry', 'The Toyota Production System (TPS)', and 'Influence of Taiichi Ohno'. For each sub-topic, provide a title and a brief one-sentence description. The main 'content' array for this topic should be empty.",
    howItWorks: "Generate a parent report section for 'How 5S Works'. Your primary goal is to define the 5 pillars as sub-topics. For each of the 5 pillars (Sort/Seiri, Set in Order/Seiton, Shine/Seiso, Standardize/Seiketsu, Sustain/Shitsuke), provide a title and a brief one-sentence description. The main 'content' array for this topic should be empty.",
    keysToSuccess: "Generate a parent report section for 'Keys to Success in 5S'. Your primary goal is to define 3-4 critical success factors as sub-topics. Examples could include 'Management Commitment & Leadership', 'Comprehensive Employee Training', 'Consistent Auditing and Feedback', and 'Visual Management Systems'. For each sub-topic, provide a title and a brief one-sentence description. The main 'content' array for this topic should be empty.",
    failureReasons: "Generate a parent report section for 'Why 5S Implementations Fail'. Your primary goal is to define 3-4 common pitfalls as sub-topics. Examples could include 'Lack of Sustained Management Support', 'Viewing 5S as a One-Time Project', 'Inadequate Training and Resources', and 'Resistance to Cultural Change'. For each sub-topic, provide a title and a brief one-sentence description. The main 'content' array for this topic should be empty.",
    risks: "Generate a parent report section for 'Risks of Poor 5S Implementation'. Your primary goal is to define 3-4 potential negative outcomes as sub-topics. Examples could include 'Decreased Employee Morale', 'Wasted Time and Resources', 'Superficial or Ineffective Implementation', and 'Creation of New Safety Hazards'. For each sub-topic, provide a title and a brief one-sentence description. The main 'content' array for this topic should be empty.",
    benefits: "Generate a parent report section for the 'Benefits of 5S'. Your primary goal is to define 3-4 key benefit categories as sub-topics. Examples could include 'Improved Workplace Safety', 'Increased Productivity and Efficiency', 'Enhanced Product Quality', and 'Higher Employee Morale and Engagement'. For each sub-topic, provide a title and a brief one-sentence description. The main 'content' array for this topic should be empty.",
};


export const generateResearchForTopic = async (topic: keyof ResearchData): Promise<ResearchSection> => {
  try {
    const prompt = `
      You are an expert in lean manufacturing.
      ${prompts[topic]}
      Ensure the language is professional and suitable for a business/manufacturing audience.
      Provide the response in the specified JSON schema.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: sectionSchema,
        temperature: 0.5,
      },
    });

    const jsonText = response.text.trim();
    const parsedData: ResearchSection = JSON.parse(jsonText);
    return parsedData;

  } catch (error) {
    console.error(`Error generating research for topic "${topic}":`, error);
    throw new Error(`Failed to communicate with the Gemini API for topic "${topic}".`);
  }
};

export const generateDetailForSubTopic = async (parentTopicTitle: string, subTopic: SubTopic): Promise<ResearchSection> => {
    try {
        const prompt = `
            You are an expert in lean manufacturing.
            Generate a detailed report section on the sub-topic: "${subTopic.title}".
            This is a key component of the broader concept of "${parentTopicTitle}".
            Explain its purpose, core principles, and provide 2-3 practical examples of its application in a workplace.
            The response must be structured in the specified JSON schema, with a clear title and the content as an array of strings. Do not include any further sub-topics.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                // We use a simplified schema here as sub-topics don't have their own sub-topics
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING },
                        content: { type: Type.ARRAY, items: { type: Type.STRING } },
                    },
                    required: ['title', 'content'],
                },
                temperature: 0.5,
            },
        });

        const jsonText = response.text.trim();
        const parsedData: ResearchSection = JSON.parse(jsonText);
        return parsedData;

    } catch (error) {
        console.error(`Error generating detail for sub-topic "${subTopic.title}":`, error);
        throw new Error(`Failed to communicate with the Gemini API for sub-topic "${subTopic.title}".`);
    }
};

export const generateAnswerForQuestion = async (question: string): Promise<ResearchSection> => {
    try {
        const prompt = `
            You are an expert in the 5S lean manufacturing methodology.
            A user has asked the following question: "${question}"
            Provide a comprehensive but concise answer to this question.
            Structure your answer with a clear title and 3-5 key points as an array of strings.
            The title should be a rephrasing of the user's question, suitable as a section header.
            Ensure the language is professional and suitable for a business/manufacturing audience.
            Provide the response in the specified JSON schema. Do not include any sub-topics, the 'subTopics' array should not be present.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING },
                        content: { type: Type.ARRAY, items: { type: Type.STRING } },
                    },
                    required: ['title', 'content'],
                },
                temperature: 0.5,
            },
        });

        const jsonText = response.text.trim();
        const parsedData: ResearchSection = JSON.parse(jsonText);
        return parsedData;

    } catch (error) {
        console.error(`Error generating answer for question "${question}":`, error);
        throw new Error(`Failed to communicate with the Gemini API for your question.`);
    }
};

export const generateImageForResearch = async (section: ResearchSection): Promise<string> => {
    try {
        const contentSummary = section.content.map(point => `- ${point}`).join('\n');
        const prompt = `
            Create a visually appealing infographic slide in the style of a Canva template. 
            The slide is for a professional corporate training presentation on the '5S Methodology'.
            The main topic of this slide is: "${section.title}".
            Key points to visually represent are:
            ${contentSummary}
            
            Aesthetic Guidelines:
            - Use a clean, modern, and minimalist design.
            - The color palette should be professional, centered around cyan, slate blue, and white, suitable for a dark-mode background.
            - Incorporate simple, universally understood icons to represent the key points.
            - Text should be legible, concise, and well-integrated into the design.
            - The overall feel should be informative and engaging, like a high-quality presentation slide.
            - Do not include any logos or branding.
        `;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: prompt }],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });

        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
              const base64ImageBytes: string = part.inlineData.data;
              return `data:image/png;base64,${base64ImageBytes}`;
            }
        }
        throw new Error("No image data found in the response.");

    } catch(error) {
        console.error(`Error generating image for topic "${section.title}":`, error);
        throw new Error(`Failed to generate a visual for "${section.title}".`);
    }
};