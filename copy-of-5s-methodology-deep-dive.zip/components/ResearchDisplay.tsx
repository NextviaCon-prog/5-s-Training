
import React from 'react';
import type { ResearchData, ResearchSection } from '../types';
import SectionCard from './SectionCard';

interface ResearchDisplayProps {
  data: ResearchData;
}

const ResearchDisplay: React.FC<ResearchDisplayProps> = ({ data }) => {
  // Define the order of sections for consistent display
  const sectionOrder: (keyof ResearchData)[] = [
    'origins',
    'howItWorks',
    'benefits',
    'keysToSuccess',
    'failureReasons',
    'risks',
  ];

  return (
    <div className="w-full animate-fade-in space-y-8">
      {sectionOrder.map((key) => {
        const section = data[key] as ResearchSection;
        if (!section) return null;
        return <SectionCard key={key} title={section.title} content={section.content} />;
      })}
    </div>
  );
};

export default ResearchDisplay;
