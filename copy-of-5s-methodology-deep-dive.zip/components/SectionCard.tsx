import React from 'react';
import LoadingSpinner from './LoadingSpinner';

interface SectionCardProps {
  title: string;
  // Fix: Made imageUrl optional to support content-only cards.
  imageUrl?: string | null;
  // Fix: Added optional content prop to display text points.
  content?: string[];
}

const SectionCard: React.FC<SectionCardProps> = ({ title, imageUrl, content }) => {
  return (
    <div className="bg-slate-800/50 border border-slate-700 rounded-2xl shadow-lg backdrop-blur-sm overflow-hidden w-full">
      <h2 className="text-2xl font-bold text-cyan-400 p-4 sm:p-6 border-b border-slate-700">
        {title}
      </h2>
      <div className="p-4 sm:p-6 min-h-[400px] flex items-center justify-center">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={`Visual representation for ${title}`}
            className="w-full h-auto max-w-3xl rounded-lg object-contain animate-fade-in"
          />
        // Fix: Render content as a list if imageUrl is not present but content is.
        ) : content && content.length > 0 ? (
          <div className="text-left text-slate-300 w-full max-w-3xl">
            <ul className="list-disc space-y-2 pl-5">
              {content.map((point, index) => (
                <li key={index}>{point}</li>
              ))}
            </ul>
          </div>
        ) : (
          // This can be shown while the image is loading, or if it fails.
          // The main loading logic is in App.tsx
          <LoadingSpinner text="Loading visual..." />
        )}
      </div>
    </div>
  );
};

export default SectionCard;
